
Hi, I am Abu Huraira, 

This is my project, it solves a "Work Load" problem. Like, in any businesses or in anywhere sometime we need a healping hand to help us for a short period of time. Like Eid-Time, Puza-Time, any national occation or traditional ocation Cloth business face extra work load to handle customers, they feel if they can find any helping hand for this working load time only. So, 'MicroJob' will create a platform, where this type of short period job will post with job details, those yangstars are engaged with this platform, they can apply for it, Job provider will contact them, talk with them and reqruit them if they feel satisfied. This is how businessman and worker both will get helped with it.


Copyright Worning!

all right reserved by me. Copying any part of it, or using any part of it, is not permitted to anyone nor anywere.
