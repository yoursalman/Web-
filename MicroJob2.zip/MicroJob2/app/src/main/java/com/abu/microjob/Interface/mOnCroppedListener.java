package com.abu.microjob.Interface;

import android.net.Uri;

public interface mOnCroppedListener {
    void mGetCroppedImgResult(Uri cropped_img_uri);
}
