package com.abu.microjob.Interface;

import com.google.firebase.auth.FirebaseAuth;

public interface MyFirebaseAuthProvider {

    FirebaseAuth getFirebaseAuth();

}
