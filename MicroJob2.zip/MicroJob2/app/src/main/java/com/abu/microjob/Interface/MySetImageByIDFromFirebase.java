package com.abu.microjob.Interface;

import android.app.Activity;

import com.abu.microjob.Model.RecruiterModel;

public interface MySetImageByIDFromFirebase<T> {
    void mSetImage(T user, Activity activity);
//    void mSetImage(RecruiterModel user, Activity activity);
}
