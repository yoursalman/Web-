package com.abu.microjob.Interface;

public interface MySetTitleInMainActivity {
    void mSetMainActivityTitle(String title);
}
