package com.abu.microjob.Interface;

import android.app.Activity;

public interface MyApplyFunctionalityListener {
    void mPerformApply(String[] data, Activity activity);

}
